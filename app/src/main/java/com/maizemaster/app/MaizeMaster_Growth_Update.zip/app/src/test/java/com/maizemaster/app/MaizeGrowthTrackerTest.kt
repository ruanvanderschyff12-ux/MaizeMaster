package com.maizemaster.app

import org.junit.Assert.*
import org.junit.Test
import java.time.LocalDate

class MaizeGrowthTrackerTest {
    private fun field() = SavedField("test", "North", "Rectangle", 100.0, 100.0,
        0.75, 0.25, "White maize", 5.0)

    @Test fun existingFieldsRequirePlantingDate() {
        assertTrue(MaizeGrowthTracker.summary(field()).contains("set your planting date"))
    }

    @Test fun calendarAgeCrossesLeapDay() {
        val f = field().copy(plantingDate = "2024-02-28")
        assertTrue(MaizeGrowthTracker.summary(f, LocalDate.of(2024, 3, 1))
            .contains("2 days since planting"))
    }

    @Test fun futurePlantingDoesNotProduceNegativeProgress() {
        val f = field().copy(plantingDate = "2026-10-20", maturityDays = 120)
        val result = MaizeGrowthTracker.summary(f, LocalDate.of(2026, 10, 12))
        assertTrue(result.contains("Planting planned in 8 days"))
        assertTrue(result.contains("Calendar progress: 0%"))
    }

    @Test fun elapsedTargetDoesNotInventObservedStageOrHarvestReadiness() {
        val f = field().copy(plantingDate = "2026-01-01", maturityDays = 100)
        val result = MaizeGrowthTracker.summary(f, LocalDate.of(2026, 10, 12))
        assertTrue(result.contains("Target date reached"))
        assertTrue(result.contains("Calendar progress: 100%"))
        assertTrue(result.contains("Observed stage: Not recorded"))
        assertFalse(result.contains("ready to harvest"))
    }

    @Test fun recordedStageAndDateRemainVisible() {
        val f = field().copy(plantingDate = "2026-09-01", growthStage = "Emergence",
            growthObservedDate = "2026-09-08")
        val result = MaizeGrowthTracker.summary(f, LocalDate.of(2026, 10, 12))
        assertTrue(result.contains("Emergence (observed 2026-09-08)"))
        assertTrue(result.contains("Maturity target: not set"))
    }
}
